package com.example.myapplication.utils;

public class Const {

	public static final String URL_JSON_OBJECT = "https://api.androidhive.info/volley/person_object.json";
	public static final String URL_JSON_ARRAY = "https://api.androidhive.info/volley/person_array.json";


/*
	public static final String URL_JSON_OBJECT = "https://221b9c71-b8cf-4604-a22c-01a1fd5b2b02.mock.pstmn.io/MovieCategory";
	public static final String URL_JSON_ARRAY = "https://221b9c71-b8cf-4604-a22c-01a1fd5b2b02.mock.pstmn.io/MovieCategory";
*/
	public static final String URL_STRING_REQ = "https://api.androidhive.info/volley/string_response.html";
	public static final String URL_IMAGE = "https://api.androidhive.info/volley/volley-image.jpg";
}
