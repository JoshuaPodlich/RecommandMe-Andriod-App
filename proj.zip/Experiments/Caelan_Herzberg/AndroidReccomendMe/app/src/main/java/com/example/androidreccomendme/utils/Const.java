package com.example.androidreccomendme.utils;

public class Const {

	//public static final String URL_JSON_OBJECT = "https://api.androidhive.info/volley/person_object.json";
	//public static final String URL_JSON_ARRAY = "https://api.androidhive.info/volley/person_array.json";



	public static final String URL_JSON_OBJECT = "http://coms-309-018.class.las.iastate.edu:8080/Movie/info";
	public static final String URL_JSON_ARRAY = "http://coms-309-018.class.las.iastate.edu:8080/Movie/info";

	public static final String URL_STRING_REQ = "https://api.androidhive.info/volley/string_response.html";
	public static final String URL_IMAGE = "https://api.androidhive.info/volley/volley-image.jpg";
}
